SAVANNA BREW WEBSITE

HOW TO VIEW
1. Extract the ZIP file.
2. Open the savanna-brew-website folder.
3. Double-click index.html to open the website in a browser.

FILES
- index.html: Home page
- about.html: About page
- menu.html: Menu page
- gallery.html: Gallery page
- contact.html: Contact and reservation page
- css/style.css: Shared responsive styling
- resources/: Supplied logo, banners, gallery photos and founder portrait

NOTES
- Built with HTML and CSS; a small JavaScript snippet displays a demo reservation confirmation.
- The reservation form is front-end only. It does not transmit or store bookings. Connect a backend or booking service before using it for real reservations.
- Contact details, menu items, prices, story and opening hours are reproduced from the supplied reference screenshots and should be confirmed before publication.
- The map is an embedded Google Maps search for Westlands, Nairobi, not a verified pin for the exact street address.
- Google Fonts and the map embed require an internet connection.
